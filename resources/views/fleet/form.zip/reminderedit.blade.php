{{ Form::model($reminder, ['route' => ['reminder.update', $reminder->id], 'method' => 'PUT']) }}
    <div class="modal-body">

        <div class="row">
            <div class="form-group">
                {{ Form::label('next_reminder_date', __('Next Reminder Date')) }}
                {{ Form::date('next_reminder_date', $reminder->next_reminder_date, array('class' => 'form-control', 'required' => 'required')) }}
            </div>
        </div>

    </div>
    <div class="modal-footer">
        <input type="button" value="{{__('Cancel')}}" class="btn btn-light" data-bs-dismiss="modal">
        <input type="submit" value="{{__('Update')}}" class="btn btn-primary">
    </div>
{{ Form::close() }}
