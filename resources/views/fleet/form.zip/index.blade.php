@extends('layouts.admin')
@section('page-title')
    {{__('Forward Planner')}}
@endsection
@push('script-page')
<script src='https://cdn.jsdelivr.net/npm/fullcalendar@5.10.1/main.min.js'></script>
<script>
    document.addEventListener('DOMContentLoaded', function() {
        var calendarEl = document.getElementById('calendar');
        var events = @json($events); // Ensure you're passing the events correctly

        var calendar = new FullCalendar.Calendar(calendarEl, {
            initialView: 'dayGridMonth',
            headerToolbar: {
                left: 'prev,next today',
                center: 'title',
                right: 'dayGridMonth,timeGridWeek,timeGridDay'
            },
            events: events, // Pass the events here
            eventColor: '#3788d8', // Default color for events
            eventContent: function(arg) {
        // Use the Planner Type as the main title and the Registration Number below it
        var plannerType = arg.event.title; // Planner Type
        var registrationNumber = arg.event.extendedProps.registration_number; // Registration Number
        
        return {
            html: `
                <div style="text-align: center;">
                                    <span>(${registrationNumber})</span><br/>
                    <strong>${plannerType}</strong>
                </div>
            `
        };
    },
            eventClick: function(info) {
                var eventTitle = info.event.title;

                // Get event details and other properties
                var eventStart = info.event.start;
                var eventStatus = info.event.extendedProps.status || 'Pending';
                var redirectUrl = info.event.extendedProps.redirectUrl;
                var eventId = info.event.id;
                var registrationNumber = info.event.extendedProps.registration_number;

                var eventComment = info.event.extendedProps.comment || '';
                var eventOdometerReading = info.event.extendedProps.odometer_reading || '';
                var eventPartsCost = info.event.extendedProps.parts_cost || '';
                var eventLabourCost = info.event.extendedProps.labour_cost || '';
                var eventTyreCost = info.event.extendedProps.tyre_cost || '';
                var eventTotalCost = info.event.extendedProps.total_cost || '';

                var formattedStartDate = eventStart.toLocaleDateString('en-GB');

                // Set event details in modal
                document.getElementById('eventTitle').innerText = eventTitle;
                document.getElementById('eventStart').innerText = formattedStartDate;
                document.getElementById('eventStatus').innerText = eventStatus;
                document.getElementById('registrationNumber').innerText = registrationNumber;

                // Handle the condition for hiding/showing fields based on event title
                if (eventTitle === 'PMI Due' || eventTitle === 'Brake Test Due') {
                    // Hide the Comment, Odometer, File Upload, and Cost Section fields
                    document.getElementById('eventComment').closest('div').style.display = 'none';
                    document.getElementById('eventOdometerReading').closest('div').style.display = 'none';
                    document.getElementById('eventFiles').closest('div').style.display = 'none';
                    document.querySelector('label[for="cost"]').closest('div').style.display = 'none';

                    // Hide the Save Changes button for PMI Due and Brake Test Due
                    document.getElementById('saveChangesButton').style.display = 'none';
                } else {
                    // Show the Comment, Odometer, File Upload, and Cost Section fields
                    document.getElementById('eventComment').closest('div').style.display = 'block';
                    document.getElementById('eventOdometerReading').closest('div').style.display = 'block';
                    document.getElementById('eventFiles').closest('div').style.display = 'block';
                    document.querySelector('label[for="cost"]').closest('div').style.display = 'block';

                    // Show the Save Changes button if it's not PMI Due or Brake Test Due
                    document.getElementById('saveChangesButton').style.display = 'inline-block';
                }

                // Set other field values
                document.getElementById('eventComment').value = eventComment;
                document.getElementById('eventOdometerReading').value = eventOdometerReading;
                document.getElementById('parts').value = eventPartsCost;
                document.getElementById('labour').value = eventLabourCost;
                document.getElementById('tyre_cost').value = eventTyreCost;
                document.getElementById('total_cost').value = eventTotalCost;

                // Enable/Disable Save Changes button based on start date and status
                var currentDate = new Date();
                var saveChangesButton = document.getElementById('saveChangesButton');

                if (eventStatus === 'Completed' && eventStart <= currentDate) {
                    saveChangesButton.style.display = 'none';
                } else {
                    saveChangesButton.style.display = 'inline-block';
                }

                if (eventStart <= currentDate && eventStatus !== 'Completed') {
                    saveChangesButton.disabled = false;
                } else {
                    saveChangesButton.disabled = true;
                }

                // Conditionally show or hide the "Update Status" button based on the event title
                var updateStatusButton = document.getElementById('updateStatusButton');
                if (eventTitle === 'PMI Due' || eventTitle === 'Brake Test Due') {
                    updateStatusButton.style.display = 'inline-block';
                    saveChangesButton.style.display = 'none';

                } else {
                    updateStatusButton.style.display = 'none';
                    saveChangesButton.style.display = 'inline-block';

                }

                document.getElementById('redirectButton').onclick = function() {
                    window.location.href = redirectUrl;
                };

                document.getElementById('updateStatusButton').onclick = function() {
                    window.location.href = `/form-page/${eventId}`;
                };

                document.getElementById('saveChangesButton').onclick = function() {
                    var updatedComment = document.getElementById('eventComment').value;
                    var updatedOdometerReading = document.getElementById('eventOdometerReading').value;
                    var updatedPartsCost = document.getElementById('parts').value;
                    var updatedLabourCost = document.getElementById('labour').value;
                    var updatedTyreCost = document.getElementById('tyre_cost').value;
                    var updatedTotalCost = document.getElementById('total_cost').value;
                    var files = document.getElementById('eventFiles').files;

                    var formData = new FormData();
                    formData.append('comment', updatedComment);
                    formData.append('odometer_reading', updatedOdometerReading);
                    formData.append('parts', updatedPartsCost);
                    formData.append('labour', updatedLabourCost);
                    formData.append('tyre_cost', updatedTyreCost);
                    formData.append('total_cost', updatedTotalCost);

                    Array.from(files).forEach(function(file) {
                        formData.append('files[]', file);
                    });

                    fetch(`/update-event/${eventId}`, {
                        method: 'POST',
                        headers: {
                            'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content')
                        },
                        body: formData
                    }).then(response => response.json())
                      .then(data => {
                          if (data.success) {
                                      location.reload(); // Reload the page after success
                          } else {
                              alert('Failed to save changes.');
                          }
                      }).catch(error => {
                          console.error('Error:', error);
                          alert('An error occurred while saving changes.');
                      });
                };

                var myModal = new bootstrap.Modal(document.getElementById('eventModal'));
                myModal.show();
            }




        });

        calendar.render();
    });




    document.addEventListener('DOMContentLoaded', function() {
        // Elements for cost fields
        const partsInput = document.getElementById('parts');
        const labourInput = document.getElementById('labour');
        const tyreCostInput = document.getElementById('tyre_cost');
        const totalCostInput = document.getElementById('total_cost');

        // Function to calculate total cost
        function calculateTotalCost() {
            const parts = parseFloat(partsInput.value) || 0;
            const labour = parseFloat(labourInput.value) || 0;
            const tyreCost = parseFloat(tyreCostInput.value) || 0;

            const totalCost = parts + labour + tyreCost;
            totalCostInput.value = totalCost.toFixed(2); // Update the Total Cost field
        }

        // Event listeners to calculate the total cost whenever a field changes
        partsInput.addEventListener('input', calculateTotalCost);
        labourInput.addEventListener('input', calculateTotalCost);
        tyreCostInput.addEventListener('input', calculateTotalCost);
    });
</script>



@endpush

@section('breadcrumb')
    <li class="breadcrumb-item"><a href="{{route('dashboard')}}">{{__('Dashboard')}}</a></li>
    <li class="breadcrumb-item">{{__('Forward Planner')}}</li>
@endsection

@section('action-btn')
@can('create depot')
    <div class="float-end">
        <a href="#" data-size="md" data-url="{{ route('fleet.create') }}" data-ajax-popup="true" data-bs-toggle="tooltip" title="{{__('Create')}}" data-title="{{__('New Planner')}}" class="btn btn-sm btn-primary">
            <i class="ti ti-plus"></i>
        </a>
    </div>
@endcan
@endsection

@section('content')
    <div class="row">
        <div class="col-lg-12">
            <div class="card">
                <div class="card-header">
                    <div class="row">
                        <div class="col-lg-6">
                            <h5>{{ __('Forward Planner') }}</h5>
                        </div>
                        <div class="col-lg-6">
                            @if (isset($setting['google_calendar_enable']) && $setting['google_calendar_enable'] == 'on')
                                <select class="form-control" name="calendar_type" id="calendar_type" style="float: right;width: 150px;" onchange="get_data()">
                                    <option value="google_calendar">{{__('Google Calendar')}}</option>
                                    <option value="local_calendar" selected="true">{{__('Local Calendar')}}</option>
                                </select>
                            @endif
                        </div>
                    </div>
                </div>
                <div class="card-body">
                    <div id='calendar' style="min-height: 400px;"></div>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal for event details -->
    <div class="modal fade" id="eventModal" tabindex="-1" aria-labelledby="eventModalLabel" aria-hidden="true">
      <div class="modal-dialog">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="eventModalLabel">Edit <span id="eventTitle"></span></h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
          </div>
          <div class="modal-body">
            <!--<p><strong>Title: </strong><span id="eventTitle"></span></p>-->
            <p><strong>Start: </strong><span id="eventStart"></span></p>
            <p><strong>Status: </strong><span id="eventStatus"></span></p>
                        <p><strong>Vehicle Registration Number: </strong><span id="registrationNumber"></span></p>

                    <div>
                        <strong>Comment: </strong>
                        <textarea id="eventComment" class="form-control"></textarea>
                    </div>
                    <div>
                        <strong>Odometer Reading: </strong>
                        <input type="number" id="eventOdometerReading" class="form-control" />
                    </div>
                    <div>
                        <strong>Upload Files: </strong>
                        <input type="file" id="eventFiles" class="form-control" multiple />
                    </div>
                    <!-- Cost Section -->
                    <div class="mt-4">
                        <label for="cost" class="form-label"><strong>Cost</strong></label>
                        <div class="row mb-3">
                            <div class="col-md-4 mb-2">
                                <label for="parts">Parts Cost</label>
                                <input type="number" class="form-control" name="parts" id="parts" placeholder="Enter Parts Cost" value="{{ old('parts') }}" step="0.01" min="0">
                            </div>
                            <div class="col-md-4 mb-2">
                                <label for="labour">Labour Cost</label>
                                <input type="number" class="form-control" name="labour" id="labour" placeholder="Enter Labour Cost" value="{{ old('labour') }}" step="0.01" min="0">
                            </div>
                            <div class="col-md-4 mb-2">
                                <label for="tyre_cost">Tyre Cost</label>
                                <input type="number" class="form-control" name="tyre_cost" id="tyre_cost" placeholder="Enter Tyre Cost" value="{{ old('tyre_cost') }}" step="0.01" min="0">
                            </div>
                        </div>
                        <div class="row mb-3">
                            <div class="col-md-12">
                                <label for="total_cost">Total Cost</label>
                                <input type="number" class="form-control" name="total_cost" id="total_cost" placeholder="Total Cost" value="{{ old('total_cost') }}" step="0.01" readonly>
                            </div>
                        </div>
                    </div>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-primary" id="redirectButton">Go to Planner Reminder Details</button>
                                <button type="button" class="btn btn-warning" id="updateStatusButton">Open Form</button>
                                <button type="button" id="saveChangesButton" class="btn btn-primary">Save Changes</button>
            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
          </div>
        </div>
      </div>
    </div>


@endsection
