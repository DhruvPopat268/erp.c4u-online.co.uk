@extends('layouts.admin')

@section('page-title')
    {{ __('Planner Reminder Details') }}
@endsection

@section('breadcrumb')
    <li class="breadcrumb-item"><a href="{{ route('dashboard') }}">{{ __('Dashboard') }}</a></li>
    <li class="breadcrumb-item"><a href="{{ route('fleet.index') }}">{{ __('Planner Reminder') }}</a></li>
    <li class="breadcrumb-item active">{{ __('Planner Reminder Details') }}</li>
@endsection

@section('content')
    <div class="row">
        <!-- Fleet Details Section -->
        <div class="col-lg-12">
            <div class="card">
                <div class="card-header">
                    <h5>{{ __('Planner Reminder Information ') }} {{ $fleet->name }}</h5>
                </div>
                <div class="card-body">
                    <table class="table table-bordered">
                        <tr>
                            <th>{{ __('Planner Type') }}</th>
                            <td>{{ $fleet->planner_type }}</td>
                            <th>{{ __('Company Name') }}</th>
                            <td>{{ $fleet->company->name ?? 'N/A' }}</td>
                        </tr>
                        <tr>
                            <th>{{ __('Start Date') }}</th>
                            <td>{{ \Carbon\Carbon::parse($fleet->start_date)->format('d/m/Y') }}</td>
                            <th>{{ __('End Date') }}</th>
                            <td>{{ \Carbon\Carbon::parse($fleet->end_date)->format('d/m/Y') }}</td>
                        </tr>
                    </table>
                </div>

            </div>
        </div>
    </div>

    <!-- Fleet Reminders Section -->
    @if($reminders->isNotEmpty())
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-body table-border-style">
                        <div class="table-responsive">
                            <table class="table datatable">
                                <thead>
                                    <tr>
                                        <th>{{ __('Action') }}</th>
                                        <th>{{ __('Reminder Date') }}</th>
                                        <th>{{ __('Status') }}</th>

                                    </tr>
                                </thead>
                                <tbody>
                                    @php
                                        $editIconShown = false; // Flag to track if the edit icon is shown
                                    @endphp
                                    @foreach($reminders as $reminder)
                                        <tr>
                                            <td class="text-center">
                                                @if($reminder->status === 'Pending' && !$editIconShown)
                                                    <div class="action-btn bg-info ms-2">
                                                        <a href="#" class="mx-3 btn btn-sm d-inline-flex align-items-center"
                                                           data-url="{{ route('reminder.edit', $reminder->id) }}"
                                                           data-ajax-popup="true"
                                                           data-size="md"
                                                           data-bs-toggle="tooltip"
                                                           title="{{ __('Edit') }}"
                                                           data-title="{{ __('Edit Type') }}">
                                                            <i class="ti ti-pencil text-white"></i>
                                                        </a>
                                                    </div>
                                                    @php
                                                        $editIconShown = true; // Set the flag to true after showing the icon
                                                    @endphp
                                                @endif

                                                <div class="action-btn bg-danger ms-2">
                                                    {!! Form::open(['method' => 'DELETE', 'route' => ['reminder.destroy', $reminder->id]]) !!}
                                                    <a href="#" class="mx-3 btn btn-sm align-items-center bs-pass-para" data-bs-toggle="tooltip" title="{{ __('Delete') }}">
                                                        <i class="ti ti-trash text-white"></i>
                                                    </a>
                                                    {!! Form::close() !!}
                                                </div>
                                            </td>
                                            <td class="text-center">{{ \Carbon\Carbon::parse($reminder->next_reminder_date)->format('d/m/Y') }}</td>
                                            <td class="text-center">{{ $reminder->status }}</td>
                                        </tr>
                                    @endforeach
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    @else
        <p>{{ __('No reminders available.') }}</p>
    @endif
@endsection
