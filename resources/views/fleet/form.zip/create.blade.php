{{ Form::open(array('url' => 'fleet')) }}
    <div class="modal-body">

        <div class="form-group">
            {{ Form::label('company_id', __('Company Name'), ['class' => 'form-label']) }}
            {{ Form::select('company_id', array_map('strtoupper', $contractTypes->toArray()), null, ['class' => 'form-control', 'data-toggle="select"', 'required' => 'required', 'id' => 'company_id']) }}
        </div>

        <div class="row">
            <div class="form-group">
                {{ Form::label('vehicle_id', __('Vehicle')) }}
                {{ Form::select('vehicle_id', [], null, ['class' => 'form-control', 'required' => 'required', 'id' => 'vehicle_id']) }}
            </div>
        </div>

        <div class="row">
            <div class="form-group">
                {{ Form::label('planner_type', __('Planner Type')) }}
                {{ Form::select('planner_type', ['' => __('Select Planner Type'), 'Tacho Calibration' => 'Tacho Calibration', 'DVS/PSS Permit Expiry' => 'DVS/PSS Permit Expiry', 'Insurance' => 'Insurance', 'PMI Due' => 'PMI Due', 'Brake Test Due' => 'Brake Test Due'], null, ['class' => 'form-control', 'required' => 'required']) }}
            </div>
        </div>

        <div class="row">
            <div class="form-group">
                {{ Form::label('start_date', __('Start date')) }}
                {{ Form::date('start_date', '', array('class' => 'form-control')) }}
            </div>
            <div class="form-group">
                {{ Form::label('end_date', __('End date')) }}
                {{ Form::date('end_date', '', array('class' => 'form-control')) }}
            </div>
        </div>

        <div class="row">
            <div class="form-group col-md-6">
                {{ Form::label('every', __('Every')) }}
                {{ Form::number('every', '', ['class' => 'form-control', 'min' => 1, 'required' => 'required']) }}
            </div>
            <div class="form-group col-md-6">
                {{ Form::label('interval', __('Interval')) }}
                {{ Form::select('interval', ['Day' => __('Day'), 'Week' => __('Week'), 'Month' => __('Month')], null, ['class' => 'form-control', 'required' => 'required', 'placeholder' => __('Select Interval')]) }}
            </div>
        </div>

    </div>
    <div class="modal-footer">
        <input type="button" value="{{__('Cancel')}}" class="btn btn-light" data-bs-dismiss="modal">
        <input type="submit" value="{{__('Create')}}" class="btn btn-primary">
    </div>
{{ Form::close() }}

<script>
    // When company is selected, fetch vehicles for that company
    document.getElementById('company_id').addEventListener('change', function() {
        var companyId = this.value;
        
        // Clear the vehicle dropdown before updating
        var vehicleSelect = document.getElementById('vehicle_id');
        vehicleSelect.innerHTML = '<option value="">{{ __('Select Vehicle') }}</option>'; // Default option

        if (companyId) {
            fetch('/vehicles/' + companyId)
                .then(response => response.json())
                .then(data => {
                    for (var id in data) {
                        var option = document.createElement('option');
                        option.value = id;
                        option.textContent = data[id];
                        vehicleSelect.appendChild(option);
                    }
                });
        }
    });
</script>
