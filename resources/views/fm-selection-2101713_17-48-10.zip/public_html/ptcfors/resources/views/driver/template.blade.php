
@php
$logo=\App\Models\Utility::get_file('uploads/logo/');
$dark_logo    = Utility::getValByName('dark_logo');
$img = asset($logo . '/' . (isset($dark_logo) && !empty($dark_logo) ? $dark_logo : 'logo-dark.png'));
$settings    = Utility::settings();
@endphp

@extends('layouts.contractheader')
@section('page-title')

@endsection
<style>
             .datetested {
            color: #505a5f;
            font-size: 1.1875rem;
            line-height: 1.3157894737;
            font-family: "GDS Transport", arial, sans-serif;
            -webkit-font-smoothing: antialiased;
            -moz-osx-font-smoothing: grayscale;
            font-weight: 400;
            display: block;
            text-align: left;
        }

        .datetestedvalue {
            margin-bottom: 5px !important;
            font-size: 1.1875rem;
            line-height: 1.3157894737;
            color: #0b0c0c;
            font-family: "GDS Transport", arial, sans-serif;
            -webkit-font-smoothing: antialiased;
            -moz-osx-font-smoothing: grayscale;
            font-weight: 700;
            display: block;
            margin-top: 0;
        }

        #pass-fail {
            color: #00703c;
            margin-bottom: 0 !important;
            font-size: 2rem;
            line-height: 1.0416666667;
            font-family: "GDS Transport", arial, sans-serif;
            -webkit-font-smoothing: antialiased;
            -moz-osx-font-smoothing: grayscale;
            font-weight: 700;
            display: block;
            margin-top: -20px;
        }

        .datetestedmileage {
            color: #505a5f;
            font-size: 1.1875rem;
            line-height: 1.3157894737;
            font-family: "GDS Transport", arial, sans-serif;
            -webkit-font-smoothing: antialiased;
            -moz-osx-font-smoothing: grayscale;
            font-weight: 400;
            display: block;
            text-align: left;
            margin-left: 135%;
            margin-top: -40%;
        }

        .datetestedvaluemileage {
            margin-bottom: 5px !important;
            font-size: 1.1875rem;
            line-height: 1.3157894737;
            color: #0b0c0c;
            font-family: "GDS Transport", arial, sans-serif;
            -webkit-font-smoothing: antialiased;
            -moz-osx-font-smoothing: grayscale;
            font-weight: 700;
            display: block;
            margin-top: -92px;
            margin-left: 135%;


        }

        .datetestedcertificate {
            color: #505a5f;
            font-size: 1.1875rem;
            line-height: 1.3157894737;
            font-family: "GDS Transport", arial, sans-serif;
            -webkit-font-smoothing: antialiased;
            -moz-osx-font-smoothing: grayscale;
            font-weight: 400;
            display: block;
            text-align: left;
            margin-left: 418%;
            margin-top: -76%;

        }

        .datetestedvaluecertificate {
            margin-bottom: 5px !important;
            font-size: 1.1875rem;
            line-height: 1.3157894737;
            color: #0b0c0c;
            font-family: "GDS Transport", arial, sans-serif;
            -webkit-font-smoothing: antialiased;
            -moz-osx-font-smoothing: grayscale;
            font-weight: 700;
            display: block;
            margin-top: -130px;
            margin-left: 419%;

        }

        .datetestedlocation {
            color: #505a5f;
            font-size: 1.1875rem;
            line-height: 1.3157894737;
            font-family: "GDS Transport", arial, sans-serif;
            -webkit-font-smoothing: antialiased;
            -moz-osx-font-smoothing: grayscale;
            font-weight: 400;
            display: block;
            text-align: left;
            margin-left: 136%;
            margin-top: 21%;

        }

        .datetestedvalueloction {
            margin-bottom: 5px !important;
            font-size: 1.1875rem;
            line-height: 1.3157894737;
            color: #0b0c0c;
            font-family: "GDS Transport", arial, sans-serif;
            -webkit-font-smoothing: antialiased;
            -moz-osx-font-smoothing: grayscale;
            font-weight: 700;
            display: block;
            margin-top: 23%;
            margin-left: 137%;
        }

        .datetestedexpirydate {
            color: #505a5f;
            font-size: 1.1875rem;
            line-height: 1.3157894737;
            font-family: "GDS Transport", arial, sans-serif;
            -webkit-font-smoothing: antialiased;
            -moz-osx-font-smoothing: grayscale;
            font-weight: 400;
            display: block;
            text-align: left;
            margin-left: 418%;
            margin-top: 26%;

        }

        .datetestedvalueexpirydate {
            margin-bottom: 5px !important;
            font-size: 1.1875rem;
            line-height: 1.3157894737;
            color: #0b0c0c;
            font-family: "GDS Transport", arial, sans-serif;
            -webkit-font-smoothing: antialiased;
            -moz-osx-font-smoothing: grayscale;
            font-weight: 700;
            display: block;
            margin-top: 56px;
            margin-left: 419%;

        }

        .heading h3 {
            font-size: 1.1875rem;
            line-height: 1.3157894737;
            font-family: "GDS Transport", arial, sans-serif;
            -webkit-font-smoothing: antialiased;
            -moz-osx-font-smoothing: grayscale;
            font-weight: 400;
            display: block;
            color: #505a5f;
            margin-left: 35%;
        }

        .heading li {
            font-weight: 700 !important;
            text-align: -webkit-match-parent;
            list-style-type: disc;
            font-size: 1.1875rem;
            line-height: 1.3157894737;
            font-family: "GDS Transport", arial, sans-serif;
            -webkit-font-smoothing: antialiased;
            color: #0b0c0c;
            margin-top: -17px;
            margin-bottom: 15px;
            padding-left: 0;
            margin-left: 35%;
            width: 60ch;
        }

        .heading h1 {
            text-decoration: underline;
            color: #1d70b8;
            cursor: pointer;
            list-style: inside disclosure-closed;
            font-size: 1.1875rem;
            line-height: 1.3157894737;
            font-family: "GDS Transport", arial, sans-serif;
            -webkit-font-smoothing: antialiased;
            -moz-osx-font-smoothing: grayscale;
            font-weight: 400;
            margin-bottom: 20px;
            display: block;
            margin-left: 27%;
        }

         .heading p {
            display: block;
            margin-top: 0;
            margin-bottom: 20px;
            font-size: 1.1875rem;
            line-height: 1.3157894737;
            font-family: "GDS Transport", arial, sans-serif;
            -webkit-font-smoothing: antialiased;
            -moz-osx-font-smoothing: grayscale;
            font-weight: 400;
            color: #0b0c0c;
            margin-bottom: 20px;
            margin-left: 27%;

        }

        .govuk-details[open]>.govuk-details__summary:before {
            display: block;
            width: 0;
            height: 0;
            border-style: solid;
            border-color: rgba(0, 0, 0, 0);
            -webkit-clip-path: polygon(0% 0%, 50% 100%, 100% 0%);
            clip-path: polygon(0% 0%, 50% 100%, 100% 0%);
            border-width: 12.124px 7px 0 7px;
            border-top-color: inherit;
        }

        .govuk-details__summary:before {
            content: "";
            position: absolute;
            top: -1px;
            bottom: 0;
            left: 0;
            margin: auto;
            display: block;
            width: 0;
            height: 0;
            border-style: solid;
            border-color: rgba(0, 0, 0, 0);
            -webkit-clip-path: polygon(0% 0%, 100% 50%, 0% 100%);
            clip-path: polygon(0% 0%, 100% 50%, 0% 100%);
            border-width: 7px 0 7px 12.124px;
            border-left-color: inherit;
        }

        .govuk-details__summary {
            display: inline-block;
            position: relative;
            margin-bottom: 5px;
            padding-left: 25px;
            color: #1d70b8;
            cursor: pointer;
        }

        details[open]>summary:first-of-type {
            list-style-type: disclosure-open;
        }

        details>summary:first-of-type {
            list-style: inside disclosure-closed;
        }

        .govuk-details {
            font-family: "GDS Transport", arial, sans-serif;
            -webkit-font-smoothing: antialiased;
            -moz-osx-font-smoothing: grayscale;
            font-weight: 400;
            font-size: 1.1875rem;
            line-height: 1.3157894737;
            line-height: 1.25;
            color: #0b0c0c;
            margin-bottom: 20px;
            display: block;
            margin-left: 3%;
        }

        .govuk-details__text {
            padding-top: 15px;
            padding-bottom: 15px;
            padding-left: 20px;
            border-left: 5px solid #b1b4b6;
        }

        .govuk-details__summary-text {
            text-decoration: underline;
        }

        .dvsa-vrm {
            display: inline-block;
            min-width: 150px;
            font: 30px UK-VRM, Verdana, sans-serif;
            padding: .4em .2em;
            text-align: center;
            background-color: #fd0;
            border-radius: .25em;
            text-transform: uppercase;
        }

        .govuk-\!-margin-bottom-1 {
            margin-bottom: 5px !important;
        }

        .govuk-heading-xl {
            color: #0b0c0c;
            font-family: "GDS Transport", arial, sans-serif;
            -webkit-font-smoothing: antialiased;
            -moz-osx-font-smoothing: grayscale;
            font-weight: 700;
            font-size: 32px;
            font-size: 2rem;
            line-height: 1.09375;
            display: block;
            margin-top: 0;
            margin-bottom: 30px;
        }

        .govuk-grid-column-one-third {
            box-sizing: border-box;
            width: 100%;
            padding: 0 15px;
        }

        .govuk-grid-column-one-third2 {
            box-sizing: border-box;
            width: 100%;
            padding: 0 15px;
        }

        .govuk-caption-m {
            font-family: "GDS Transport", arial, sans-serif;
            -webkit-font-smoothing: antialiased;
            -moz-osx-font-smoothing: grayscale;
            font-weight: 400;
            font-size: 16px;
            font-size: 1rem;
            line-height: 1.25;
            display: block;
            color: #505a5f;
        }

        .govuk-caption-m2 {
            font-family: "GDS Transport", arial, sans-serif;
            -webkit-font-smoothing: antialiased;
            -moz-osx-font-smoothing: grayscale;
            font-weight: 400;
            font-size: 1.1875rem;
            line-height: 1.3157894737;
            display: block;
            color: #505a5f;
        }

        .govuk-caption-m3 {
            font-family: "GDS Transport", arial, sans-serif;
            -webkit-font-smoothing: antialiased;
            -moz-osx-font-smoothing: grayscale;
            font-weight: 400;
            font-size: 1.1875rem;
            line-height: 1.3157894737;
            display: block;
            color: #505a5f;
        }

        .govuk-heading-m {
            color: #0b0c0c;
            font-family: "GDS Transport", arial, sans-serif;
            -webkit-font-smoothing: antialiased;
            -moz-osx-font-smoothing: grayscale;
            font-weight: 700;
            font-size: 18px;
            font-size: 1.125rem;
            line-height: 1.1111111111;
            display: block;
            margin-top: 0;
            margin-bottom: 15px;
        }

        .govuk-heading-m2 {
            color: #0b0c0c;
            font-family: "GDS Transport", arial, sans-serif;
            -webkit-font-smoothing: antialiased;
            -moz-osx-font-smoothing: grayscale;
            font-weight: 700;
            font-size: 1.1875rem;
            line-height: 1.3157894737;
            display: block;
            margin-top: 0;
            margin-bottom: 15px;
        }

        .govuk-heading-m3 {
            color: #0b0c0c;
            font-family: "GDS Transport", arial, sans-serif;
            -webkit-font-smoothing: antialiased;
            -moz-osx-font-smoothing: grayscale;
            font-weight: 700;
            font-size: 1.1875rem;
            line-height: 1.3157894737;
            display: block;
            margin-top: 0;
            margin-bottom: 15px;
        }

        .govuk-caption-l {
            font-family: "GDS Transport", arial, sans-serif;
            -webkit-font-smoothing: antialiased;
            -moz-osx-font-smoothing: grayscale;
            font-weight: 400;
            font-size: 18px;
            font-size: 1.125rem;
            line-height: 1.1111111111;
            display: block;
            margin-bottom: 5px;
            color: #505a5f;
        }

        .govuk-heading-l {
            color: #0b0c0c;
            font-family: "GDS Transport", arial, sans-serif;
            -webkit-font-smoothing: antialiased;
            -moz-osx-font-smoothing: grayscale;
            font-weight: 700;
            font-size: 24px;
            font-size: 1.5rem;
            line-height: 1.0416666667;
            display: block;
            margin-top: 0;
            margin-bottom: 20px;
        }

        @media (min-width: 40.0625em) {
            .govuk-heading-xl {
                margin-bottom: 50px;
                font-size: 3rem;
                line-height: 1.0416666667;
            }

            .govuk-grid-column-one-third {
                width: 33.3333333333%;
                float: left;
            }

            .govuk-caption-m {
                font-size: 19px;
                font-size: 1.0875rem;
                line-height: 1.3157894737;
            }

            .govuk-caption-m2 {
                font-size: 1.1875rem;
                line-height: 1.3157894737;
            }

            .govuk-heading-m {
                margin-bottom: 20px;
                font-size: 1.1875rem;
                line-height: 1.25;
            }

            .govuk-heading-m2 {
                margin-bottom: 20px;
                font-size: 1.1875rem;
                line-height: 1.3157894737;
            }

            .govuk-caption-l {
                margin-bottom: 0;
                font-size: 1.5rem;
                line-height: 1.25;
            }

            .govuk-heading-l {
                margin-bottom: 30px;
                font-size: 1.25rem;
                line-height: 1.1111111111;
            }
        }
        </style>

@section('title')

@endsection
@php
    use Carbon\Carbon;
@endphp

@section('content')

<div class="row">
    <div class="col-lg-10">
        <div class="container">
            <div>
                <div class="card mt-5" id="printTable" style="margin-left: 180px;margin-right: -57px;">
                    <div class="card-body" id="boxes">


                        <div class="row">
                           <h2>Test</h2>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>



@endsection

@push('script-page')
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
<script type="text/javascript" src="{{ asset('js/html2pdf.bundle.min.js') }}"></script>
<script>
    function closeScript() {
        setTimeout(function () {
            window.open(window.location, '_self').close();
        }, 1000);
    }

    $(window).on('load', function () {
        var element = document.getElementById('boxes');
        var opt = {
            filename: '{{App\Models\Utility::contractNumberFormat($driver->id)}}',
            image: {type: 'jpeg', quality: 1},
            html2canvas: {scale: 4, dpi: 72, letterRendering: true},
            jsPDF: {unit: 'in', format: 'A4'}
        };

        html2pdf().set(opt).from(element).save().then(closeScript);
    });
</script>
@endpush


